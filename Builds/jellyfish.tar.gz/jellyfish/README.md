
@about project
=====
Chrysaora jellyfish project it's GDM login screen for linux systems but it's not just a screen. it's a life cycle simulator the jellyfishes can reproduce themselves. some born some dies , which is most amazing thing in this project. We are working on some new algorithms for making this life cycle simulator better. 



about Chrysaora jellyfish
=====
Chrysaora is a genus of the family Pelagiidae (Jellyfish)
A recent analysis of the genus found there to be 12 valid species.
The origin of the genus name Chrysaora lies in Greek mythology with Chrysaor,
brother of Pegasus and son of Poseidon and Medusa.
Translated, Chrysaor means "he who has a golden armament".


coder   -  sameer AKA sam0hack
============
company -  ILM technosolutions
============
web     -  http://ilmtechnosolutions.com?team=sameer
============
email      sam.nyx@live.com
============



